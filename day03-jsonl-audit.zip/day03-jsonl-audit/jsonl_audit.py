"""Streaming JSONL dataset validation for AI and data pipelines."""
import argparse
import json
from collections import Counter
from pathlib import Path


def reject_constant(value):
    raise ValueError(f'Nonstandard JSON constant: {value}')


def audit(lines, required=(), max_examples=10):
    if max_examples < 0:
        raise ValueError('max_examples must be nonnegative')
    counts = Counter()
    fields = Counter()
    examples = []
    for number, line in enumerate(lines, 1):
        counts['lines'] += 1
        reason = None
        if not line.strip():
            reason = 'blank'
        else:
            try:
                obj = json.loads(line, parse_constant=reject_constant)
            except ValueError:
                reason = 'invalid_json'
            else:
                if not isinstance(obj, dict):
                    reason = 'not_object'
                elif any(key not in obj or obj[key] is None for key in required):
                    reason = 'missing_required'
                else:
                    counts['valid'] += 1
                    fields.update(obj.keys())
        if reason:
            counts[reason] += 1
            if len(examples) < max_examples:
                examples.append({'line': number, 'reason': reason})
    return {'lines': counts['lines'], 'valid': counts['valid'],
            'invalid': counts['lines'] - counts['valid'],
            'errors': {k: counts[k] for k in ('blank','invalid_json','not_object','missing_required')},
            'field_frequency': dict(sorted(fields.items())), 'examples': examples}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('file', type=Path)
    p.add_argument('--require', action='append', default=[])
    p.add_argument('--max-examples', type=int, default=10)
    p.add_argument('--output', type=Path)
    args = p.parse_args(argv)
    try:
        if args.output and args.output.resolve() == args.file.resolve():
            raise ValueError('output must differ from input')
        with args.file.open(encoding='utf-8') as stream:
            report = audit(stream, args.require, args.max_examples)
        result = json.dumps(report, indent=2)
        if args.output:
            args.output.write_text(result + '\n', encoding='utf-8')
        print(result)
        return int(report['invalid'] > 0)
    except (OSError, ValueError) as exc:
        p.exit(2, f'Error: {exc}\n')


if __name__ == '__main__':
    raise SystemExit(main())
