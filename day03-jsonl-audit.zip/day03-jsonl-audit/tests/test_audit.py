import unittest
import tempfile
import subprocess
import sys
from pathlib import Path
from jsonl_audit import audit

class AuditTests(unittest.TestCase):
    def test_valid(self):
        self.assertEqual(audit(['{"x":1}'])['valid'], 1)
    def test_blank(self):
        self.assertEqual(audit(['\n'])['errors']['blank'], 1)
    def test_malformed(self):
        self.assertEqual(audit(['{'])['errors']['invalid_json'], 1)
    def test_nan(self):
        self.assertEqual(audit(['{"x":NaN}'])['invalid'], 1)
    def test_nonobject(self):
        self.assertEqual(audit(['[]'])['errors']['not_object'], 1)
    def test_required(self):
        self.assertEqual(audit(['{}','{"x":null}','{"x":false}'], ['x'])['valid'], 1)
    def test_limit(self):
        self.assertEqual(len(audit(['bad']*20,max_examples=2)['examples']),2)
    def test_frequency(self):
        self.assertEqual(audit(['{"x":1}','{"x":2,"y":3}'])['field_frequency'],{'x':2,'y':1})
    def test_empty(self):
        self.assertEqual(audit([])['invalid'],0)
    def test_cli(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'data.jsonl'; f.write_text('{}\nbad\n')
            out=Path(d)/'report.json'
            r=subprocess.run([sys.executable,'-m','jsonl_audit',str(f),'--output',str(out)],capture_output=True)
            self.assertEqual(r.returncode,1)
            self.assertTrue(out.exists())
    def test_negative_limit(self):
        with self.assertRaises(ValueError): audit([],max_examples=-1)
